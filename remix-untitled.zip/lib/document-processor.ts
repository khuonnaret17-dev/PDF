import JSZip from 'jszip';
import mammoth from 'mammoth';
import { DocumentSourceType } from '@/types/document';
import { saveBinaryRecord } from '@/lib/local-binary-store';
import {
  PAGE_BREAK_SENTINEL,
  convertDocxZipToHtml,
  decodeWin1252Byte,
  escapeHtml,
  extractFormattedHtmlBody,
  legacyDocTextToHtml,
  markdownToHtml,
  parseRtfToHtml,
  plainTextToPreservedHtml,
} from '@/lib/format-parsers';

export interface ImportedDocumentResult {
  title: string;
  sourceType: DocumentSourceType;
  contentHtml: string;
  plainText: string;
  pageCountEstimate: number;
  needsOcrHint?: boolean;
  binaryBytes?: ArrayBuffer;
  mimeType: string;
  fileName: string;
  thumbnailDataUrl?: string;
  pageDataUrls?: string[];
  pageSizesPt?: Array<{ widthPt: number; heightPt: number }>;
  extractedTextPages?: string[];
}

const MAX_STORAGE_HTML_BYTES = 560000;
const MAX_STORAGE_PLAIN_BYTES = 180000;
const MAX_SINGLE_IMAGE_DATA_URL_BYTES = 360000;

const utf8Encoder = new TextEncoder();
const utf8Decoder = new TextDecoder();

function utf8ByteLength(str: string): number {
  return utf8Encoder.encode(str).byteLength;
}

function clampUtf8(str: string, maxBytes: number): string {
  const encoded = utf8Encoder.encode(str);
  if (encoded.byteLength <= maxBytes) return str;
  return utf8Decoder.decode(encoded.slice(0, maxBytes)).replace(/\uFFFD+$/g, '');
}

function stripHtmlToPlain(html: string): string {
  if (typeof window === 'undefined') {
    return html.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
  }
  const div = document.createElement('div');
  div.innerHTML = html;
  return (div.textContent || div.innerText || '').replace(/\s+/g, ' ').trim();
}

function segmentTextUnits(text: string): string[] {
  if (!text) return [];
  const IntlWithSegmenter = Intl as unknown as {
    Segmenter?: new (
      locale?: string,
      opts?: { granularity: 'grapheme' | 'word' | 'sentence' }
    ) => { segment: (input: string) => Iterable<{ segment: string }> };
  };

  if (typeof IntlWithSegmenter.Segmenter === 'function') {
    try {
      const seg = new IntlWithSegmenter.Segmenter('km', { granularity: 'word' });
      const parts = Array.from(seg.segment(text), (s) => s.segment);
      if (parts.length > 1) return parts;
    } catch {
      // Fallback below
    }
    try {
      const graphemeSeg = new IntlWithSegmenter.Segmenter(undefined, { granularity: 'grapheme' });
      return Array.from(graphemeSeg.segment(text), (s) => s.segment);
    } catch {
      // Fallback below
    }
  }
  return Array.from(text);
}

function splitLongPlainText(text: string, maxBytes: number): string[] {
  if (!text) return [];
  if (utf8ByteLength(text) <= maxBytes) return [text];

  const hasWhitespace = /\s/.test(text);
  const rawTokens = hasWhitespace ? text.split(/(\s+)/) : segmentTextUnits(text);
  const units: string[] = [];

  for (const tok of rawTokens) {
    if (utf8ByteLength(tok) > maxBytes) {
      units.push(...segmentTextUnits(tok));
    } else {
      units.push(tok);
    }
  }

  const chunks: string[] = [];
  let current = '';
  let currentBytes = 0;

  for (const unit of units) {
    const unitBytes = utf8ByteLength(unit);
    if (current && currentBytes + unitBytes > maxBytes) {
      const trimmed = current.trim();
      if (trimmed) chunks.push(trimmed);
      current = unit;
      currentBytes = unitBytes;
    } else {
      current += unit;
      currentBytes += unitBytes;
    }
  }
  const tail = current.trim();
  if (tail) chunks.push(tail);
  return chunks.length > 0 ? chunks : [clampUtf8(text, maxBytes)];
}

function textToParagraphHtml(text: string): string {
  return plainTextToPreservedHtml(text);
}

function readOle2Streams(buffer: ArrayBuffer): Map<string, Uint8Array> | null {
  try {
    if (buffer.byteLength < 512) return null;
    const view = new DataView(buffer);
    const bytes = new Uint8Array(buffer);
    const oleMagic = [0xd0, 0xcf, 0x11, 0xe0, 0xa1, 0xb1, 0x1a, 0xe1];
    for (let i = 0; i < 8; i++) {
      if (bytes[i] !== oleMagic[i]) return null;
    }

    const sectorShift = view.getUint16(30, true);
    const miniSectorShift = view.getUint16(32, true);
    const sectorSize = 1 << sectorShift;
    const miniSectorSize = 1 << miniSectorShift;
    if (sectorSize < 64 || sectorSize > 8192 || miniSectorSize < 16) return null;

    const numFatSectors = view.getInt32(44, true);
    const firstDirSector = view.getInt32(48, true);
    const miniStreamCutoff = view.getUint32(56, true);
    const firstMiniFatSector = view.getInt32(60, true);
    const numMiniFatSectors = view.getInt32(64, true);
    const firstDifatSector = view.getInt32(68, true);
    const numDifatSectors = view.getInt32(72, true);

    const ENDOFCHAIN = -2;
    const FREESECT = -1;

    const getSectorOffset = (secId: number) => 512 + secId * sectorSize;
    const readSector = (secId: number): Uint8Array => {
      const off = getSectorOffset(secId);
      if (off < 0 || off + sectorSize > bytes.length) {
        return bytes.subarray(Math.max(0, off), Math.min(bytes.length, off + sectorSize));
      }
      return bytes.subarray(off, off + sectorSize);
    };

    const fatSectorIds: number[] = [];
    for (let i = 0; i < 109 && fatSectorIds.length < numFatSectors; i++) {
      const sid = view.getInt32(76 + i * 4, true);
      if (sid >= 0) fatSectorIds.push(sid);
    }

    let difatSec = firstDifatSector;
    let difatLoops = 0;
    while (
      difatSec >= 0 &&
      difatSec !== ENDOFCHAIN &&
      difatSec !== FREESECT &&
      fatSectorIds.length < numFatSectors &&
      difatLoops < numDifatSectors + 4
    ) {
      difatLoops++;
      const off = getSectorOffset(difatSec);
      if (off + sectorSize > bytes.length) break;
      const entries = sectorSize / 4 - 1;
      for (let i = 0; i < entries && fatSectorIds.length < numFatSectors; i++) {
        const sid = view.getInt32(off + i * 4, true);
        if (sid >= 0) fatSectorIds.push(sid);
      }
      difatSec = view.getInt32(off + entries * 4, true);
    }

    const fatEntriesPerSector = sectorSize / 4;
    const fat = new Int32Array(fatSectorIds.length * fatEntriesPerSector);
    for (let sIdx = 0; sIdx < fatSectorIds.length; sIdx++) {
      const off = getSectorOffset(fatSectorIds[sIdx]);
      if (off + sectorSize > bytes.length) continue;
      for (let j = 0; j < fatEntriesPerSector; j++) {
        fat[sIdx * fatEntriesPerSector + j] = view.getInt32(off + j * 4, true);
      }
    }

    const readChain = (startSec: number, maxLen?: number): Uint8Array => {
      const chunks: Uint8Array[] = [];
      const visited = new Set<number>();
      let cur = startSec;
      let total = 0;
      while (cur >= 0 && cur < fat.length && !visited.has(cur)) {
        visited.add(cur);
        const secBytes = readSector(cur);
        chunks.push(secBytes);
        total += secBytes.length;
        if (maxLen !== undefined && total >= maxLen) break;
        cur = fat[cur];
      }
      const outLen = maxLen !== undefined ? Math.min(total, maxLen) : total;
      const out = new Uint8Array(outLen);
      let pos = 0;
      for (const c of chunks) {
        const take = Math.min(c.length, outLen - pos);
        if (take <= 0) break;
        out.set(c.subarray(0, take), pos);
        pos += take;
      }
      return out;
    };

    const dirBytes = readChain(firstDirSector);
    const dirView = new DataView(dirBytes.buffer, dirBytes.byteOffset, dirBytes.byteLength);
    const entrySize = 128;
    const numEntries = Math.floor(dirBytes.length / entrySize);

    let rootStartSector = -1;
    let rootSize = 0;
    const streamEntries: Array<{ name: string; startSector: number; size: number }> = [];

    for (let idx = 0; idx < numEntries; idx++) {
      const base = idx * entrySize;
      const objType = dirBytes[base + 66];
      const nameLen = dirView.getUint16(base + 64, true);
      if (nameLen < 2 || nameLen > 64) continue;
      const nameBytes = dirBytes.subarray(base, base + nameLen - 2);
      const name = new TextDecoder('utf-16le').decode(nameBytes);
      const startSector = dirView.getInt32(base + 116, true);
      const sizeLow = dirView.getUint32(base + 120, true);
      if (objType === 5) {
        rootStartSector = startSector;
        rootSize = sizeLow;
      } else if (objType === 2) {
        streamEntries.push({ name, startSector, size: sizeLow });
      }
    }

    const miniStream =
      rootStartSector >= 0 && rootSize > 0 ? readChain(rootStartSector, rootSize) : new Uint8Array(0);
    const miniFatRaw =
      firstMiniFatSector >= 0 && numMiniFatSectors > 0 ? readChain(firstMiniFatSector) : new Uint8Array(0);
    const miniFatView = new DataView(miniFatRaw.buffer, miniFatRaw.byteOffset, miniFatRaw.byteLength);
    const miniFat = new Int32Array(Math.floor(miniFatRaw.length / 4));
    for (let i = 0; i < miniFat.length; i++) {
      miniFat[i] = miniFatView.getInt32(i * 4, true);
    }

    const readMiniChain = (startSec: number, size: number): Uint8Array => {
      const out = new Uint8Array(size);
      const visited = new Set<number>();
      let cur = startSec;
      let pos = 0;
      while (cur >= 0 && cur < miniFat.length && pos < size && !visited.has(cur)) {
        visited.add(cur);
        const off = cur * miniSectorSize;
        const take = Math.min(miniSectorSize, size - pos, miniStream.length - off);
        if (take <= 0) break;
        out.set(miniStream.subarray(off, off + take), pos);
        pos += take;
        cur = miniFat[cur];
      }
      return out;
    };

    const result = new Map<string, Uint8Array>();
    for (const entry of streamEntries) {
      const data =
        entry.size < miniStreamCutoff && miniStream.length > 0
          ? readMiniChain(entry.startSector, entry.size)
          : readChain(entry.startSector, entry.size);
      result.set(entry.name, data);
    }
    return result;
  } catch {
    return null;
  }
}

function extractWordBinaryTextFromOle2(buffer: ArrayBuffer): string | null {
  const streams = readOle2Streams(buffer);
  if (!streams) return null;
  const wordDoc = streams.get('WordDocument');
  if (!wordDoc || wordDoc.length < 0x1b0) return null;

  const wView = new DataView(wordDoc.buffer, wordDoc.byteOffset, wordDoc.byteLength);
  const magic = wView.getUint16(0, true);
  if (magic !== 0xa5ec && magic !== 0xa5dc) return null;

  const flags = wView.getUint16(0x0a, true);
  const fEncrypted = (flags & 0x0100) !== 0;
  if (fEncrypted) return null;
  const fWhichTblStm = (flags & 0x0200) !== 0;
  const tableName = fWhichTblStm ? '1Table' : '0Table';
  const tableStream = streams.get(tableName) || streams.get('1Table') || streams.get('0Table');
  if (!tableStream) return null;

  const ccpText = wView.getInt32(0x4c, true);
  if (ccpText <= 0) return null;

  // Locate fcClx / lcbClx in FibRgFcLcb97 (offset 0x1a2 in WordDocument)
  if (wordDoc.length < 0x1aa) return null;
  const fcClx = wView.getUint32(0x1a2, true);
  const lcbClx = wView.getUint32(0x1a6, true);
  if (lcbClx === 0 || fcClx + lcbClx > tableStream.length) return null;

  const clx = tableStream.subarray(fcClx, fcClx + lcbClx);
  const clxView = new DataView(clx.buffer, clx.byteOffset, clx.byteLength);
  let pos = 0;

  // Skip optional Prc structures (clxt === 0x01)
  while (pos < clx.length && clx[pos] === 0x01) {
    if (pos + 3 > clx.length) return null;
    const cbGrpprl = clxView.getUint16(pos + 1, true);
    pos += 3 + cbGrpprl;
  }

  if (pos >= clx.length || clx[pos] !== 0x02) return null;
  pos += 1;
  if (pos + 4 > clx.length) return null;
  const lcbPcd = clxView.getUint32(pos, true);
  pos += 4;
  if (pos + lcbPcd > clx.length || lcbPcd < 12) return null;

  const nPieces = Math.floor((lcbPcd - 4) / 12);
  if (nPieces <= 0) return null;

  const cpBase = pos;
  const pcdBase = pos + (nPieces + 1) * 4;
  let fullText = '';

  for (let i = 0; i < nPieces; i++) {
    const cpStart = clxView.getUint32(cpBase + i * 4, true);
    const cpEnd = clxView.getUint32(cpBase + (i + 1) * 4, true);
    if (cpStart >= ccpText) break;
    const clampedEnd = Math.min(cpEnd, ccpText);
    const charCount = clampedEnd - cpStart;
    if (charCount <= 0) continue;

    const pcdOffset = pcdBase + i * 8;
    const fcRaw = clxView.getUint32(pcdOffset + 2, true);
    const isAnsiCompressed = (fcRaw & 0x40000000) !== 0;
    const fc = isAnsiCompressed ? (fcRaw & 0x3fffffff) >> 1 : fcRaw;

    if (isAnsiCompressed) {
      if (fc + charCount > wordDoc.length) continue;
      for (let k = 0; k < charCount; k++) {
        fullText += decodeWin1252Byte(wordDoc[fc + k]);
      }
    } else {
      const byteLen = charCount * 2;
      if (fc + byteLen > wordDoc.length) continue;
      fullText += new TextDecoder('utf-16le', { fatal: false }).decode(
        wordDoc.subarray(fc, fc + byteLen)
      );
    }
  }

  // Preserve \r paragraphs, \x0c page breaks, \x07 table delimiters, and \x0b line breaks
  const cleaned = fullText
    .replace(/\r\n/g, '\n')
    .replace(/\r/g, '\n')
    .replace(/[\x00-\x06\x08\x0e-\x1f]/g, '')
    .trim();

  return cleaned || null;
}

function extractLegacyDocText(buffer: ArrayBuffer): string {
  const oleText = extractWordBinaryTextFromOle2(buffer);
  if (oleText && oleText.length >= 10) {
    return oleText;
  }

  const bytes = new Uint8Array(buffer);
  const runs: string[] = [];

  const utf16Text = new TextDecoder('utf-16le', { fatal: false }).decode(bytes);
  const utf16Regex = /[\t\n\r\u0020-\u007E\u00A0-\u00FF\u1780-\u17FF\u2010-\u2027]{8,}/g;
  const utf16Matches = utf16Text.match(utf16Regex) || [];
  for (const m of utf16Matches) {
    const cleaned = m
      .replace(/[^\t\n\u0020-\u007E\u00A0-\u00FF\u1780-\u17FF\u2010-\u2027]/g, '')
      .trim();
    if (
      cleaned.length >= 8 &&
      !cleaned.includes('Microsoft Word') &&
      !cleaned.includes('Root Entry') &&
      !cleaned.includes('WordDocument')
    ) {
      runs.push(cleaned);
    }
  }

  const ascii = new TextDecoder('windows-1252', { fatal: false }).decode(bytes);
  const asciiMatches = ascii.match(/[A-Za-z0-9\u00C0-\u00FF ,.;:'"“”‘’()\-–—/\t\n]{16,}/g) || [];
  for (const m of asciiMatches) {
    const cleaned = m.trim();
    if (
      cleaned.length >= 16 &&
      !cleaned.includes('Microsoft Word') &&
      !cleaned.includes('Root Entry') &&
      !cleaned.includes('Word.Document') &&
      !runs.some((r) => r.includes(cleaned))
    ) {
      runs.push(cleaned);
    }
  }

  return runs.join('\n\n').trim() || 'Legacy binary .doc imported.';
}

export async function renderPdfPagesFromBytes(
  arrayBuffer: ArrayBuffer
): Promise<{
  pageDataUrls: string[];
  pageSizesPt: Array<{ widthPt: number; heightPt: number }>;
  extractedTextPages: string[];
  totalChars: number;
}> {
  const pdfjsLib = await import('pdfjs-dist');
  pdfjsLib.GlobalWorkerOptions.workerSrc = '/pdf.worker.min.mjs';

  const loadingTask = pdfjsLib.getDocument({
    data: arrayBuffer.slice(0),
    cMapUrl: '/pdfjs/cmaps/',
    cMapPacked: true,
    standardFontDataUrl: '/pdfjs/standard_fonts/',
  });
  const pdf = await loadingTask.promise;
  const numPages = pdf.numPages;

  const pageDataUrls: string[] = [];
  const pageSizesPt: Array<{ widthPt: number; heightPt: number }> = [];
  const extractedTextPages: string[] = [];
  let totalChars = 0;

  const preferredScale = numPages > 100 ? 1.15 : numPages > 45 ? 1.35 : 1.75;
  const jpegQuality = numPages > 100 ? 0.76 : numPages > 45 ? 0.8 : 0.88;
  const annotationMode = pdfjsLib.AnnotationMode?.ENABLE ?? 1;

  try {
    for (let p = 1; p <= numPages; p++) {
      let widthPt = 595;
      let heightPt = 842;
      let dataUrl = '';
      let pageText = '';

      try {
        const page = await pdf.getPage(p);
        const baseViewport = page.getViewport({ scale: 1 });
        widthPt = Math.max(1, Math.round(baseViewport.width));
        heightPt = Math.max(1, Math.round(baseViewport.height));

        const maxSidePt = Math.max(baseViewport.width, baseViewport.height, 1);
        const safeScale = Math.min(preferredScale, 2200 / maxSidePt);

        const renderAtScale = async (targetScale: number): Promise<string> => {
          const renderViewport = page.getViewport({ scale: targetScale });
          const canvas = document.createElement('canvas');
          canvas.width = Math.max(1, Math.floor(renderViewport.width));
          canvas.height = Math.max(1, Math.floor(renderViewport.height));
          const ctx = canvas.getContext('2d');
          if (!ctx) return '';
          try {
            ctx.fillStyle = '#ffffff';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            await page.render({
              canvasContext: ctx,
              viewport: renderViewport,
              canvas,
              annotationMode,
            }).promise;
            return canvas.toDataURL('image/jpeg', jpegQuality);
          } finally {
            canvas.width = 0;
            canvas.height = 0;
          }
        };

        try {
          dataUrl = await renderAtScale(safeScale);
        } catch {
          try {
            dataUrl = await renderAtScale(Math.min(0.75, safeScale));
          } catch {
            try {
              dataUrl = await renderAtScale(Math.min(0.4, safeScale));
            } catch {
              dataUrl = '';
            }
          }
        }

        try {
          const textContent = await page.getTextContent();
          const lines: string[] = [];
          let currentLine = '';
          let lastY: number | null = null;

          for (const item of textContent.items) {
            if ('str' in item) {
              const y = Array.isArray(item.transform) ? Math.round(item.transform[5]) : null;
              if (lastY !== null && y !== null && Math.abs(y - lastY) > 6) {
                if (currentLine.trim()) lines.push(currentLine.trim());
                currentLine = item.str;
              } else {
                currentLine += (currentLine && item.str ? ' ' : '') + item.str;
              }
              lastY = y;
            }
          }
          if (currentLine.trim()) lines.push(currentLine.trim());
          pageText = lines.join('\n').trim();
        } catch {
          pageText = '';
        }

        page.cleanup();
      } catch (pageErr) {
        console.warn(`PDF page ${p} partial recovery:`, pageErr);
      }

      pageSizesPt.push({ widthPt, heightPt });
      pageDataUrls.push(dataUrl);
      totalChars += pageText.length;
      extractedTextPages.push(pageText);
    }
  } finally {
    try {
      const destroyable = pdf as unknown as {
        destroy?: () => Promise<void> | void;
        cleanup?: () => void;
      };
      if (typeof destroyable.destroy === 'function') {
        await destroyable.destroy();
      } else if (typeof destroyable.cleanup === 'function') {
        destroyable.cleanup();
      }
    } catch {
      // Ignore cleanup errors
    }
  }

  return { pageDataUrls, pageSizesPt, extractedTextPages, totalChars };
}

export function buildEditableHtmlFromPdfTextPages(
  textPages: string[],
  pageDataUrls?: string[]
): string {
  return (
    textPages
      .map((txt, idx) => {
        if (txt && txt.trim()) {
          return textToParagraphHtml(txt);
        }
        const scanUrl = pageDataUrls?.[idx];
        if (scanUrl) {
          return `<figure><img src="${scanUrl}" alt="Page ${idx + 1}" /></figure>`;
        }
        return '<p></p>';
      })
      .join('\n<hr class="page-break-marker" />\n') || '<p></p>'
  );
}

async function processPdfFile(
  file: File,
  arrayBuffer: ArrayBuffer
): Promise<ImportedDocumentResult> {
  const { pageDataUrls, pageSizesPt, extractedTextPages, totalChars } =
    await renderPdfPagesFromBytes(arrayBuffer);
  const numPages = Math.max(1, pageDataUrls.length);

  const markerParts = pageSizesPt.map(
    (sz, idx) =>
      `<div class="dm-pdf-page-marker" data-pdf-page="${idx + 1}" data-width-pt="${sz.widthPt}" data-height-pt="${sz.heightPt}"></div>`
  );

  const contentHtml = markerParts.join('\n') || '<p></p>';
  const plainText =
    extractedTextPages.filter(Boolean).join('\n\n') || `[PDF Document: ${file.name}]`;

  return {
    title: file.name.replace(/\.[^.]+$/, '') || 'Imported PDF',
    sourceType: 'pdf',
    contentHtml,
    plainText,
    pageCountEstimate: numPages,
    needsOcrHint: totalChars < 30,
    binaryBytes: arrayBuffer,
    mimeType: 'application/pdf',
    fileName: file.name,
    thumbnailDataUrl: pageDataUrls.find(Boolean) || undefined,
    pageDataUrls,
    pageSizesPt,
    extractedTextPages,
  };
}

function readFileAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}

async function inspectAndCompressImageDataUrl(
  dataUrl: string,
  options: { maxWidth?: number; quality?: number; forceJpegOverBytes?: number } = {}
): Promise<{ dataUrl: string; width?: number; height?: number; renderable: boolean }> {
  const maxWidth = options.maxWidth ?? 1200;
  const quality = options.quality ?? 0.86;
  const forceOverBytes = options.forceJpegOverBytes ?? 260000;

  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => {
      const natW = img.naturalWidth || img.width || 0;
      const natH = img.naturalHeight || img.height || 0;

      if (dataUrl.length <= forceOverBytes && natW <= maxWidth) {
        resolve({ dataUrl, width: natW || undefined, height: natH || undefined, renderable: true });
        return;
      }

      const isPngSource = dataUrl.startsWith('data:image/png');
      const encodeAt = (mw: number, mime: 'image/png' | 'image/jpeg', q: number): string => {
        const scale = natW > mw && natW > 0 ? mw / natW : 1;
        const canvas = document.createElement('canvas');
        canvas.width = Math.max(1, Math.round(natW * scale));
        canvas.height = Math.max(1, Math.round(natH * scale));
        const ctx = canvas.getContext('2d');
        if (!ctx) return dataUrl;
        try {
          if (mime === 'image/jpeg') {
            ctx.fillStyle = '#ffffff';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
          }
          ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
          return canvas.toDataURL(mime, q);
        } finally {
          canvas.width = 0;
          canvas.height = 0;
        }
      };

      let outUrl = dataUrl;
      if (isPngSource) {
        const resizedPng = encodeAt(maxWidth, 'image/png', 1);
        if (resizedPng.length <= MAX_SINGLE_IMAGE_DATA_URL_BYTES) {
          outUrl = resizedPng;
        } else {
          outUrl = encodeAt(maxWidth, 'image/jpeg', quality);
        }
      } else {
        outUrl = encodeAt(maxWidth, 'image/jpeg', quality);
      }

      if (outUrl.length > MAX_SINGLE_IMAGE_DATA_URL_BYTES) {
        outUrl = encodeAt(Math.min(maxWidth, 900), 'image/jpeg', 0.74);
      }
      if (outUrl.length > MAX_SINGLE_IMAGE_DATA_URL_BYTES) {
        outUrl = encodeAt(Math.min(maxWidth, 640), 'image/jpeg', 0.58);
      }

      resolve({
        dataUrl: outUrl,
        width: natW || undefined,
        height: natH || undefined,
        renderable: true,
      });
    };
    img.onerror = () => resolve({ dataUrl, renderable: false });
    img.src = dataUrl;
  });
}

function preprocessDocxXmlString(xmlText: string): string {
  if (typeof DOMParser === 'undefined' || typeof XMLSerializer === 'undefined') {
    return xmlText;
  }
  const parser = new DOMParser();
  const doc = parser.parseFromString(xmlText, 'application/xml');
  if (doc.getElementsByTagName('parsererror').length > 0) {
    return xmlText;
  }

  const W_NS = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main';
  const createPageBreakParagraph = (): Element => {
    const p = doc.createElementNS(W_NS, 'w:p');
    const r = doc.createElementNS(W_NS, 'w:r');
    const br = doc.createElementNS(W_NS, 'w:br');
    br.setAttributeNS(W_NS, 'w:type', 'page');
    r.appendChild(br);
    p.appendChild(r);
    return p;
  };

  // 1. Preserve math equations (<m:oMathPara> / <m:oMath>) as plain Word text runs
  const mathElements = Array.from(doc.getElementsByTagName('m:oMath'));
  for (const mathEl of mathElements) {
    if (mathEl.parentElement?.localName === 'oMath') continue;
    const mathTexts = Array.from(mathEl.getElementsByTagName('m:t'))
      .map((t) => t.textContent || '')
      .join('');
    if (mathTexts.trim() && mathEl.parentNode) {
      const r = doc.createElementNS(W_NS, 'w:r');
      const t = doc.createElementNS(W_NS, 'w:t');
      t.setAttribute('xml:space', 'preserve');
      t.textContent = mathTexts;
      r.appendChild(t);
      const target =
        mathEl.parentElement?.localName === 'oMathPara' ? mathEl.parentElement : mathEl;
      target.parentNode?.replaceChild(r, target);
    }
  }

  // 2. Preserve <mc:AlternateContent> where <mc:Fallback> is missing or empty of content
  const altContents = Array.from(doc.getElementsByTagName('mc:AlternateContent'));
  for (const alt of altContents) {
    const fallback = Array.from(alt.children).find((c) => c.localName === 'Fallback');
    const choice = Array.from(alt.children).find((c) => c.localName === 'Choice');
    if (!choice) continue;

    const fallbackHasContent = Boolean(
      fallback &&
        ((fallback.textContent || '').trim().length > 0 ||
          fallback.getElementsByTagName('v:imagedata').length > 0 ||
          fallback.getElementsByTagName('a:blip').length > 0)
    );
    if (!fallbackHasContent && alt.parentNode) {
      const txbxList = Array.from(choice.getElementsByTagName('w:txbxContent'));
      if (txbxList.length > 0) {
        const frag = doc.createDocumentFragment();
        for (const txbx of txbxList) {
          for (const child of Array.from(txbx.children)) {
            frag.appendChild(child.cloneNode(true));
          }
        }
        alt.parentNode.replaceChild(frag, alt);
      } else {
        const frag = doc.createDocumentFragment();
        for (const child of Array.from(choice.children)) {
          frag.appendChild(child.cloneNode(true));
        }
        alt.parentNode.replaceChild(frag, alt);
      }
    }
  }

  // 3. Preserve <w:pageBreakBefore/> and mid-document <w:sectPr> section breaks
  const body = doc.getElementsByTagName('w:body')[0];
  if (body) {
    const paragraphs = Array.from(body.getElementsByTagName('w:p'));
    for (let idx = 0; idx < paragraphs.length; idx++) {
      const p = paragraphs[idx];
      const pPr = Array.from(p.children).find((c) => c.localName === 'pPr');
      if (!pPr) continue;

      const pbb = Array.from(pPr.children).find((c) => c.localName === 'pageBreakBefore');
      if (pbb && idx > 0) {
        const val = pbb.getAttribute('w:val') ?? pbb.getAttribute('val');
        if (val !== '0' && val !== 'false' && p.parentNode) {
          p.parentNode.insertBefore(createPageBreakParagraph(), p);
        }
      }

      const sectPr = Array.from(pPr.children).find((c) => c.localName === 'sectPr');
      if (sectPr && p.parentNode) {
        const typeEl = Array.from(sectPr.children).find((c) => c.localName === 'type');
        const sectType = typeEl?.getAttribute('w:val') ?? typeEl?.getAttribute('val') ?? '';
        if (sectType !== 'continuous') {
          p.parentNode.insertBefore(createPageBreakParagraph(), p.nextSibling);
        }
      }
    }
  }

  return new XMLSerializer().serializeToString(doc);
}

async function preprocessDocxBuffer(arrayBuffer: ArrayBuffer): Promise<{
  buffer: ArrayBuffer;
  fallbackText: string;
}> {
  let fallbackText = '';
  try {
    const zip = await JSZip.loadAsync(arrayBuffer);
    const docEntry = zip.file('word/document.xml');
    if (!docEntry) {
      return { buffer: arrayBuffer, fallbackText: '' };
    }
    const rawXml = await docEntry.async('string');

    if (typeof DOMParser !== 'undefined') {
      const parsed = new DOMParser().parseFromString(rawXml, 'application/xml');
      const texts = Array.from(parsed.getElementsByTagName('w:t'))
        .map((n) => n.textContent || '')
        .join(' ')
        .trim();
      fallbackText = texts;
    }

    const patchedXml = preprocessDocxXmlString(rawXml);
    if (patchedXml !== rawXml) {
      zip.file('word/document.xml', patchedXml);
      const nextBuffer = await zip.generateAsync({ type: 'arraybuffer' });
      return { buffer: nextBuffer, fallbackText };
    }
    return { buffer: arrayBuffer, fallbackText };
  } catch {
    return { buffer: arrayBuffer, fallbackText };
  }
}

async function processDocxBuffer(
  fileName: string,
  mimeType: string,
  arrayBuffer: ArrayBuffer
): Promise<ImportedDocumentResult> {
  const baseTitle = fileName.replace(/\.[^.]+$/, '') || 'Imported Document';
  let html = '';
  let fallbackText = '';

  // Primary: Direct OOXML format-preserving converter (fonts, sizes, colors, highlights, alignment, indents, spacing, tables, lists, footnotes, images)
  try {
    const zip = await JSZip.loadAsync(arrayBuffer);
    const ooxmlResult = await convertDocxZipToHtml(zip, (rawUrl) =>
      inspectAndCompressImageDataUrl(rawUrl, {
        maxWidth: 1200,
        quality: 0.85,
        forceJpegOverBytes: 260000,
      })
    );
    if (ooxmlResult) {
      html = ooxmlResult.html;
      fallbackText = ooxmlResult.fallbackText;
    }
  } catch (ooxmlErr) {
    console.warn('Direct OOXML converter fallback to Mammoth:', ooxmlErr);
  }

  // Secondary fallback: Mammoth if OOXML conversion yielded empty output
  if (!html) {
    const prepped = await preprocessDocxBuffer(arrayBuffer);
    if (!fallbackText) fallbackText = prepped.fallbackText;

    try {
      const result = await mammoth.convertToHtml(
        { arrayBuffer: prepped.buffer },
        {
          styleMap: ["br[type='page'] => hr.page-break-marker:fresh"],
          convertImage: mammoth.images.imgElement(async (image) => {
            const base64 = await image.read('base64');
            const mime = image.contentType || 'image/png';
            const rawUrl = `data:${mime};base64,${base64}`;
            const inspected = await inspectAndCompressImageDataUrl(rawUrl, {
              maxWidth: 1200,
              quality: 0.85,
              forceJpegOverBytes: 260000,
            });
            if (!inspected.renderable && inspected.dataUrl.length > MAX_SINGLE_IMAGE_DATA_URL_BYTES) {
              return {
                src: '',
                alt: `[Embedded image (${mime}) omitted: unsupported browser format]`,
              };
            }
            const attrs: { src: string } & Record<string, string> = { src: inspected.dataUrl };
            if (inspected.width && inspected.height) {
              attrs.width = String(inspected.width);
              attrs.height = String(inspected.height);
            }
            return attrs;
          }),
        }
      );
      html = (result.value || '').trim();
    } catch (err) {
      console.warn('DOCX convertToHtml fallback triggered:', err);
    }
  }

  let plain = html ? stripHtmlToPlain(html) : '';
  if (!plain && !html.includes('<img')) {
    try {
      const rawRes = await mammoth.extractRawText({ arrayBuffer });
      const rawText = (rawRes.value || '').trim() || fallbackText;
      if (rawText) {
        html = textToParagraphHtml(rawText);
        plain = stripHtmlToPlain(html);
      }
    } catch {
      if (fallbackText) {
        html = textToParagraphHtml(fallbackText);
        plain = stripHtmlToPlain(html);
      }
    }
  }

  if (!html) html = '<p></p>';
  const explicitBreaks = (html.match(/<hr[^>]*page-break-marker/gi) || []).length;

  return {
    title: baseTitle,
    sourceType: 'docx',
    contentHtml: html,
    plainText: plain,
    pageCountEstimate: Math.max(1, explicitBreaks + 1, Math.ceil(plain.length / 1800)),
    binaryBytes: arrayBuffer,
    mimeType:
      mimeType || 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    fileName,
  };
}

function looksLikeHtmlOrMhtmlDocument(text: string): boolean {
  const sample = text.slice(0, 1500).trim().toLowerCase();
  return (
    sample.startsWith('<!doctype html') ||
    sample.startsWith('<html') ||
    (sample.includes('<html') && sample.includes('<body')) ||
    (sample.includes('mime-version:') && sample.includes('text/html'))
  );
}

export async function processImportedFile(file: File): Promise<ImportedDocumentResult> {
  const ext = file.name.split('.').pop()?.toLowerCase() || '';
  const baseTitle = file.name.replace(/\.[^.]+$/, '') || 'Imported Document';

  if (ext === 'docx') {
    const arrayBuffer = await file.arrayBuffer();
    return processDocxBuffer(file.name, file.type, arrayBuffer);
  }

  if (ext === 'doc') {
    const arrayBuffer = await file.arrayBuffer();
    const head = new Uint8Array(arrayBuffer.slice(0, 16));
    // Detect files saved with a .doc extension that are actually DOCX, PDF, RTF, HTML, or MHTML
    if (head[0] === 0x50 && head[1] === 0x4b && head[2] === 0x03 && head[3] === 0x04) {
      return processDocxBuffer(file.name, file.type, arrayBuffer);
    }
    if (head[0] === 0x25 && head[1] === 0x50 && head[2] === 0x44 && head[3] === 0x46) {
      return processPdfFile(file, arrayBuffer);
    }
    const headerAscii = new TextDecoder('latin1').decode(head);
    if (headerAscii.startsWith('{\\rtf')) {
      const raw = await file.text();
      const html = parseRtfToHtml(raw);
      const plain = stripHtmlToPlain(html);
      const explicitBreaks = (html.match(/<hr[^>]*page-break-marker/gi) || []).length;
      return {
        title: baseTitle,
        sourceType: 'rtf',
        contentHtml: html,
        plainText: plain,
        pageCountEstimate: Math.max(1, explicitBreaks + 1, Math.ceil(plain.length / 1800)),
        binaryBytes: arrayBuffer,
        mimeType: 'application/rtf',
        fileName: file.name,
      };
    }

    const utf8Text = new TextDecoder('utf-8', { fatal: false }).decode(arrayBuffer);
    if (looksLikeHtmlOrMhtmlDocument(utf8Text)) {
      const html = extractFormattedHtmlBody(utf8Text);
      const plain = stripHtmlToPlain(html);
      const explicitBreaks = (html.match(/<hr[^>]*page-break-marker/gi) || []).length;
      return {
        title: baseTitle,
        sourceType: 'doc',
        contentHtml: html,
        plainText: plain,
        pageCountEstimate: Math.max(1, explicitBreaks + 1, Math.ceil(plain.length / 1800)),
        binaryBytes: arrayBuffer,
        mimeType: 'application/msword',
        fileName: file.name,
      };
    }

    const extracted = extractLegacyDocText(arrayBuffer);
    const html = legacyDocTextToHtml(extracted);
    const plain = stripHtmlToPlain(html);
    const explicitBreaks = (html.match(/<hr[^>]*page-break-marker/gi) || []).length;
    return {
      title: baseTitle,
      sourceType: 'doc',
      contentHtml: html,
      plainText: plain,
      pageCountEstimate: Math.max(1, explicitBreaks + 1, Math.ceil(plain.length / 1800)),
      binaryBytes: arrayBuffer,
      mimeType: 'application/msword',
      fileName: file.name,
    };
  }

  if (ext === 'pdf') {
    const arrayBuffer = await file.arrayBuffer();
    return processPdfFile(file, arrayBuffer);
  }

  if (ext === 'rtf') {
    const arrayBuffer = await file.arrayBuffer();
    const raw = new TextDecoder('utf-8', { fatal: false }).decode(arrayBuffer);
    const html = parseRtfToHtml(raw);
    const plain = stripHtmlToPlain(html);
    const explicitBreaks = (html.match(/<hr[^>]*page-break-marker/gi) || []).length;
    return {
      title: baseTitle,
      sourceType: 'rtf',
      contentHtml: html,
      plainText: plain,
      pageCountEstimate: Math.max(1, explicitBreaks + 1, Math.ceil(plain.length / 1800)),
      binaryBytes: arrayBuffer,
      mimeType: 'application/rtf',
      fileName: file.name,
    };
  }

  if (ext === 'txt' || ext === 'md') {
    const arrayBuffer = await file.arrayBuffer();
    const text = new TextDecoder('utf-8', { fatal: false }).decode(arrayBuffer);
    const html = ext === 'md' ? markdownToHtml(text) : plainTextToPreservedHtml(text);
    const plain = stripHtmlToPlain(html);
    const explicitBreaks = (html.match(/<hr[^>]*page-break-marker/gi) || []).length;
    return {
      title: baseTitle,
      sourceType: 'txt',
      contentHtml: html,
      plainText: plain,
      pageCountEstimate: Math.max(1, explicitBreaks + 1, Math.ceil(plain.length / 1800)),
      binaryBytes: arrayBuffer,
      mimeType: ext === 'md' ? 'text/markdown' : 'text/plain',
      fileName: file.name,
    };
  }

  if (['jpg', 'jpeg', 'png', 'webp'].includes(ext)) {
    const [arrayBuffer, rawUrl] = await Promise.all([
      file.arrayBuffer(),
      readFileAsDataUrl(file),
    ]);
    const inspected = await inspectAndCompressImageDataUrl(rawUrl, {
      maxWidth: 1600,
      quality: 0.9,
      forceJpegOverBytes: MAX_SINGLE_IMAGE_DATA_URL_BYTES,
    });
    const dimAttrs =
      inspected.width && inspected.height
        ? ` width="${inspected.width}" height="${inspected.height}"`
        : '';
    const html = `<p style="text-align: center"><img src="${inspected.dataUrl}" alt="${escapeHtml(baseTitle)}"${dimAttrs} /></p>`;
    return {
      title: baseTitle,
      sourceType: 'image',
      contentHtml: html,
      plainText: `[Image: ${file.name}]`,
      pageCountEstimate: 1,
      needsOcrHint: true,
      binaryBytes: arrayBuffer,
      mimeType: file.type || 'image/jpeg',
      fileName: file.name,
      thumbnailDataUrl: inspected.dataUrl,
    };
  }

  throw new Error(`Unsupported file type: .${ext}`);
}

const UNWRAP_STORAGE_TAGS = new Set([
  'div',
  'section',
  'article',
  'main',
  'header',
  'footer',
  'aside',
]);

function flattenHtmlElementsForStorage(container: HTMLElement): HTMLElement[] {
  const out: HTMLElement[] = [];

  const visit = (nodes: ChildNode[]) => {
    for (const node of nodes) {
      if (node.nodeType === Node.TEXT_NODE) {
        const txt = (node.textContent || '').trim();
        if (txt) {
          const p = document.createElement('p');
          p.textContent = txt;
          out.push(p);
        }
        continue;
      }
      if (node.nodeType !== Node.ELEMENT_NODE) continue;
      const el = node as HTMLElement;
      const tag = el.tagName.toLowerCase();

      if (
        el.classList.contains('dm-pdf-page-marker') ||
        el.classList.contains('dm-toc-block')
      ) {
        out.push(el);
        continue;
      }

      if (UNWRAP_STORAGE_TAGS.has(tag) && el.children.length > 0) {
        visit(Array.from(el.childNodes));
        continue;
      }

      out.push(el);
    }
  };

  visit(Array.from(container.childNodes));
  return out;
}

function splitOversizedStorageElement(
  el: HTMLElement,
  maxHtmlBytes: number,
  maxPlainBytes: number
): Array<{ html: string; plain: string }> {
  const initialHtml = el.outerHTML;
  const initialPlain = (el.textContent || '').trim();
  if (
    utf8ByteLength(initialHtml) <= maxHtmlBytes &&
    utf8ByteLength(initialPlain) <= maxPlainBytes
  ) {
    return [{ html: initialHtml, plain: initialPlain }];
  }

  const tag = el.tagName.toLowerCase();

  const styleAttr = el.getAttribute('style')
    ? ` style="${escapeHtml(el.getAttribute('style') || '')}"`
    : '';
  const classAttr = el.className ? ` class="${escapeHtml(el.className)}"` : '';

  // Split oversized <table> by direct rows while preserving table class/style
  if (tag === 'table') {
    const thead = Array.from(el.children).find((c) => c.tagName.toLowerCase() === 'thead');
    const headerHtml = thead ? thead.outerHTML : '';
    const directRows: HTMLElement[] = [];
    for (const child of Array.from(el.children)) {
      const cTag = child.tagName.toLowerCase();
      if (cTag === 'tr') directRows.push(child as HTMLElement);
      else if (cTag === 'tbody' || cTag === 'tfoot') {
        for (const r of Array.from(child.children)) {
          if (r.tagName.toLowerCase() === 'tr') directRows.push(r as HTMLElement);
        }
      }
    }
    if (directRows.length >= 2) {
      const chunks: Array<{ html: string; plain: string }> = [];
      let bucketRows: string[] = [];
      let bucketPlain: string[] = [];

      const buildTable = (rowsHtml: string[]) =>
        `<table${classAttr}${styleAttr}>${headerHtml}<tbody>${rowsHtml.join('')}</tbody></table>`;

      for (const row of directRows) {
        const rowHtml = row.outerHTML;
        const rowPlain = (row.textContent || '').trim();
        const candidateHtml = buildTable([...bucketRows, rowHtml]);
        const candidatePlain = [...bucketPlain, rowPlain].filter(Boolean).join(' ');
        if (
          bucketRows.length > 0 &&
          (utf8ByteLength(candidateHtml) > maxHtmlBytes ||
            utf8ByteLength(candidatePlain) > maxPlainBytes)
        ) {
          chunks.push({
            html: buildTable(bucketRows),
            plain: bucketPlain.filter(Boolean).join(' '),
          });
          bucketRows = [rowHtml];
          bucketPlain = rowPlain ? [rowPlain] : [];
        } else {
          bucketRows.push(rowHtml);
          if (rowPlain) bucketPlain.push(rowPlain);
        }
      }
      if (bucketRows.length > 0) {
        chunks.push({
          html: buildTable(bucketRows),
          plain: bucketPlain.filter(Boolean).join(' '),
        });
      }
      if (chunks.length > 0) return chunks;
    }
  }

  // Split oversized <ul> / <ol> by <li> items while preserving list class/style
  if (tag === 'ul' || tag === 'ol') {
    const items = Array.from(el.children).filter((c) => c.tagName.toLowerCase() === 'li');
    if (items.length >= 2) {
      const baseStart = tag === 'ol' ? Number(el.getAttribute('start')) || 1 : 1;
      const chunks: Array<{ html: string; plain: string }> = [];
      let bucketItems: string[] = [];
      let bucketPlain: string[] = [];
      let curStart = baseStart;

      const wrapList = (itemsHtml: string[], startVal: number) => {
        const startAttr = tag === 'ol' && startVal !== 1 ? ` start="${startVal}"` : '';
        return `<${tag}${startAttr}${classAttr}${styleAttr}>${itemsHtml.join('')}</${tag}>`;
      };

      items.forEach((li, idx) => {
        const liHtml = li.outerHTML;
        const liPlain = (li.textContent || '').trim();
        const candidateHtml = wrapList([...bucketItems, liHtml], curStart);
        const candidatePlain = [...bucketPlain, liPlain].filter(Boolean).join(' ');
        if (
          bucketItems.length > 0 &&
          (utf8ByteLength(candidateHtml) > maxHtmlBytes ||
            utf8ByteLength(candidatePlain) > maxPlainBytes)
        ) {
          chunks.push({
            html: wrapList(bucketItems, curStart),
            plain: bucketPlain.filter(Boolean).join(' '),
          });
          bucketItems = [liHtml];
          bucketPlain = liPlain ? [liPlain] : [];
          curStart = baseStart + idx;
        } else {
          bucketItems.push(liHtml);
          if (liPlain) bucketPlain.push(liPlain);
        }
      });
      if (bucketItems.length > 0) {
        chunks.push({
          html: wrapList(bucketItems, curStart),
          plain: bucketPlain.filter(Boolean).join(' '),
        });
      }
      if (chunks.length > 0) return chunks;
    }
  }

  // Split elements containing multiple embedded images (e.g. a single <p> holding many images)
  const imgs = Array.from(el.querySelectorAll('img'));
  if (imgs.length > 1) {
    const out: Array<{ html: string; plain: string }> = [];
    for (const img of imgs) {
      const imgHtml = `<p${classAttr}${styleAttr}>${img.outerHTML}</p>`;
      if (utf8ByteLength(imgHtml) <= maxHtmlBytes) {
        out.push({ html: imgHtml, plain: img.getAttribute('alt') || '' });
      }
    }
    if (initialPlain) {
      for (const txtPart of splitLongPlainText(initialPlain, Math.min(maxPlainBytes, 30000))) {
        out.push({ html: `<p${classAttr}${styleAttr}>${escapeHtml(txtPart)}</p>`, plain: txtPart });
      }
    }
    if (out.length > 0) return out;
  }

  // Split giant text element by plain-text chunks safely under both limits while preserving block styling
  if (initialPlain) {
    const safeTextBudget = Math.min(maxPlainBytes - 1000, Math.floor((maxHtmlBytes - 1000) / 2));
    const textPieces = splitLongPlainText(initialPlain, Math.max(4000, safeTextBudget));
    const safeTag = ['p', 'blockquote', 'pre', 'h1', 'h2', 'h3'].includes(tag) ? tag : 'p';
    return textPieces.map((piece) => ({
      html: `<${safeTag}${classAttr}${styleAttr}>${escapeHtml(piece)}</${safeTag}>`,
      plain: piece,
    }));
  }

  return [{ html: clampUtf8(initialHtml, maxHtmlBytes), plain: '' }];
}

function splitPdfResultForStorage(imported: ImportedDocumentResult): ImportedDocumentResult[] {
  const htmlBytes = utf8ByteLength(imported.contentHtml || '');
  const plainBytes = utf8ByteLength(imported.plainText || '');
  if (htmlBytes <= MAX_STORAGE_HTML_BYTES && plainBytes <= MAX_STORAGE_PLAIN_BYTES) {
    return [imported];
  }
  if (typeof window === 'undefined') {
    return [imported];
  }

  const container = document.createElement('div');
  container.innerHTML = imported.contentHtml || '';
  const markers = Array.from(container.querySelectorAll('.dm-pdf-page-marker'));
  if (markers.length <= 1) {
    return [
      {
        ...imported,
        plainText: clampUtf8(imported.plainText || imported.title, MAX_STORAGE_PLAIN_BYTES),
      },
    ];
  }

  const textPages = imported.extractedTextPages || [];
  const chunks: ImportedDocumentResult[] = [];
  let bucketHtml: string[] = [];
  let bucketPlain: string[] = [];
  let bucketHtmlBytes = 0;
  let bucketPlainBytes = 0;

  const flushPdfBucket = () => {
    if (bucketHtml.length === 0) return;
    const partIdx = chunks.length + 1;
    const html = bucketHtml.join('\n');
    const rawPlain = bucketPlain.join('\n\n').trim() || `[PDF Document: ${imported.fileName}]`;
    const plain = clampUtf8(rawPlain, MAX_STORAGE_PLAIN_BYTES);
    const isFirst = partIdx === 1;
    chunks.push({
      ...imported,
      title: clampUtf8(`${imported.title} (Part ${partIdx})`, 200),
      contentHtml: html,
      plainText: plain,
      pageCountEstimate: bucketHtml.length,
      binaryBytes: isFirst ? imported.binaryBytes : undefined,
      thumbnailDataUrl: isFirst ? imported.thumbnailDataUrl : undefined,
      pageDataUrls: isFirst ? imported.pageDataUrls : undefined,
      pageSizesPt: isFirst ? imported.pageSizesPt : undefined,
      extractedTextPages: undefined,
    });
    bucketHtml = [];
    bucketPlain = [];
    bucketHtmlBytes = 0;
    bucketPlainBytes = 0;
  };

  markers.forEach((markerEl, idx) => {
    const pageNum = Number(markerEl.getAttribute('data-pdf-page')) || idx + 1;
    const mHtml = markerEl.outerHTML;
    const pageText = (textPages[pageNum - 1] || '').trim();
    const clampedPageText =
      utf8ByteLength(pageText) > MAX_STORAGE_PLAIN_BYTES
        ? clampUtf8(pageText, MAX_STORAGE_PLAIN_BYTES)
        : pageText;
    const mHtmlBytes = utf8ByteLength(mHtml) + 1;
    const mPlainBytes = utf8ByteLength(clampedPageText) + 2;

    if (
      bucketHtml.length > 0 &&
      (bucketHtmlBytes + mHtmlBytes > MAX_STORAGE_HTML_BYTES ||
        bucketPlainBytes + mPlainBytes > MAX_STORAGE_PLAIN_BYTES)
    ) {
      flushPdfBucket();
    }

    bucketHtml.push(mHtml);
    if (clampedPageText) bucketPlain.push(clampedPageText);
    bucketHtmlBytes += mHtmlBytes;
    bucketPlainBytes += mPlainBytes;
  });
  flushPdfBucket();

  if (chunks.length === 1) {
    chunks[0].title = clampUtf8(imported.title, 200);
  }
  return chunks.length > 0 ? chunks : [imported];
}

export function splitImportedResultForStorage(
  imported: ImportedDocumentResult
): ImportedDocumentResult[] {
  if (imported.sourceType === 'pdf' && imported.contentHtml.includes('dm-pdf-page-marker')) {
    return splitPdfResultForStorage(imported);
  }

  const htmlBytes = utf8ByteLength(imported.contentHtml || '');
  const plainBytes = utf8ByteLength(imported.plainText || '');

  if (htmlBytes <= MAX_STORAGE_HTML_BYTES && plainBytes <= MAX_STORAGE_PLAIN_BYTES) {
    return [imported];
  }

  if (typeof window === 'undefined') {
    return [imported];
  }

  const container = document.createElement('div');
  container.innerHTML = imported.contentHtml || '<p></p>';
  const flattened = flattenHtmlElementsForStorage(container);
  const atomicPieces: Array<{ html: string; plain: string }> = [];

  for (const el of flattened) {
    atomicPieces.push(
      ...splitOversizedStorageElement(el, MAX_STORAGE_HTML_BYTES, MAX_STORAGE_PLAIN_BYTES)
    );
  }

  if (atomicPieces.length <= 1) {
    return [
      {
        ...imported,
        contentHtml: atomicPieces[0]?.html || clampUtf8(imported.contentHtml, MAX_STORAGE_HTML_BYTES),
        plainText:
          atomicPieces[0]?.plain || clampUtf8(imported.plainText, MAX_STORAGE_PLAIN_BYTES),
      },
    ];
  }

  const chunks: ImportedDocumentResult[] = [];
  let bucketHtml: string[] = [];
  let bucketPlain: string[] = [];
  let bucketHtmlBytes = 0;
  let bucketPlainBytes = 0;

  const flushBucket = () => {
    if (bucketHtml.length === 0) return;
    const partIdx = chunks.length + 1;
    const html = bucketHtml.join('\n');
    const plain = clampUtf8(
      bucketPlain.join('\n').trim() || imported.title,
      MAX_STORAGE_PLAIN_BYTES
    );
    const isFirst = partIdx === 1;
    const explicitBreaks = (html.match(/<hr[^>]*page-break-marker/gi) || []).length;
    chunks.push({
      ...imported,
      title: clampUtf8(`${imported.title} (Part ${partIdx})`, 200),
      contentHtml: html,
      plainText: plain,
      pageCountEstimate: Math.max(1, explicitBreaks + 1, Math.ceil(plain.length / 1800)),
      binaryBytes: isFirst ? imported.binaryBytes : undefined,
      thumbnailDataUrl: isFirst ? imported.thumbnailDataUrl : undefined,
      pageDataUrls: isFirst ? imported.pageDataUrls : undefined,
      pageSizesPt: isFirst ? imported.pageSizesPt : undefined,
      extractedTextPages: undefined,
    });
    bucketHtml = [];
    bucketPlain = [];
    bucketHtmlBytes = 0;
    bucketPlainBytes = 0;
  };

  for (const piece of atomicPieces) {
    const pieceHtmlBytes = utf8ByteLength(piece.html) + 1;
    const piecePlainBytes = utf8ByteLength(piece.plain) + 1;

    if (
      bucketHtml.length > 0 &&
      (bucketHtmlBytes + pieceHtmlBytes > MAX_STORAGE_HTML_BYTES ||
        bucketPlainBytes + piecePlainBytes > MAX_STORAGE_PLAIN_BYTES)
    ) {
      flushBucket();
    }

    bucketHtml.push(piece.html);
    if (piece.plain) bucketPlain.push(piece.plain);
    bucketHtmlBytes += pieceHtmlBytes;
    bucketPlainBytes += piecePlainBytes;
  }
  flushBucket();

  if (chunks.length === 1) {
    chunks[0].title = clampUtf8(imported.title, 200);
  }
  return chunks.length > 0 ? chunks : [imported];
}

export async function persistImportedBinaryIfPresent(
  docId: string,
  imported: ImportedDocumentResult,
  sourceBinaryDocId?: string
): Promise<void> {
  if (
    imported.binaryBytes ||
    imported.thumbnailDataUrl ||
    imported.pageDataUrls?.length ||
    sourceBinaryDocId
  ) {
    await saveBinaryRecord({
      docId,
      mimeType: imported.mimeType,
      fileName: imported.fileName,
      bytes: imported.binaryBytes,
      thumbnailDataUrl: imported.thumbnailDataUrl,
      pageDataUrls: imported.pageDataUrls,
      pageSizesPt: imported.pageSizesPt,
      sourceBinaryDocId,
    });
  }
}

export interface OcrExecutionResult {
  html: string;
  engine: 'gemini' | 'tesseract';
  notice?: string;
}

async function runLocalTesseractOcr(dataUrl: string): Promise<string> {
  const { createWorker } = await import('tesseract.js');
  const worker = await createWorker(['khm', 'eng']);
  try {
    const result = await worker.recognize(dataUrl);
    const text = (result?.data?.text || '').trim();
    return text ? textToParagraphHtml(text) : '<p>No readable text detected.</p>';
  } finally {
    await worker.terminate();
  }
}

export async function runOcrOnImageDataUrl(dataUrl: string): Promise<OcrExecutionResult> {
  const match = dataUrl.match(/^data:([^;]+);base64,(.+)$/);
  if (!match) {
    throw new Error('Invalid image data URL for OCR');
  }
  const [, mimeType, base64Data] = match;
  const res = await fetch('/api/ocr', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ mimeType, base64Data }),
  });

  if (res.ok) {
    const data = (await res.json()) as { html?: string };
    return {
      html: data.html || '<p></p>',
      engine: 'gemini',
    };
  }

  const errPayload = (await res.json().catch(() => ({ error: 'OCR request failed' }))) as {
    error?: string;
  };
  const cloudReason = errPayload.error || 'Cloud OCR unavailable.';

  if (res.status === 403 || res.status === 400 || res.status === 429) {
    try {
      const localHtml = await runLocalTesseractOcr(dataUrl);
      return {
        html: localHtml,
        engine: 'tesseract',
        notice: `${cloudReason} Extracted using local Tesseract OCR (Khmer + English).`,
      };
    } catch (localErr) {
      const localMsg = localErr instanceof Error ? localErr.message : 'Local OCR failed';
      throw new Error(`${cloudReason} Local OCR also failed: ${localMsg}`);
    }
  }

  throw new Error(cloudReason);
}
